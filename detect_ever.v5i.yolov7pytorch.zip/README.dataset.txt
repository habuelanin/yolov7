# human_detect_ever > 2024-05-07 12:00am
https://universe.roboflow.com/nti-zvemq/human_detect_ever

Provided by a Roboflow user
License: CC BY 4.0

